<div class="container-fluid">

    <footer class="text-center card w-100" >

        <!-- Copyright -->
        <div class="text-center p-3">

            <a class="text-uppercase" target="_blank"  href="mailto:adil.elmerzougui@gmail.com">عادل المرزوكي  </a>
            بمساعدة : <span class="text-uppercase" target="_blank"  > الأستاذ عبد الكريم أصاير</span><br>
            <a class="text-uppercase" target="_blank"  href="http://divmer.com">  divmer.com  </a> © 2023
        </div>
        <!-- Copyright -->
    </footer>

</div>
<?php /**PATH D:\Users\ADIL\Desktop\absences_eleves\resources\views/includes/footer.blade.php ENDPATH**/ ?>