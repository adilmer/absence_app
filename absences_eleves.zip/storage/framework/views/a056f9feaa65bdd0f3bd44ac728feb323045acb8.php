<header class="app-header " style="position: relative">
<nav class="navbar navbar-light container bg-white">
      <div class="container">
        <a href="<?php echo e(route('home.index')); ?>" class="text-nowrap logo-img">
          <img src="<?php echo e(asset('assets/images/logos/ministry-logo-ar.png')); ?>" width="80%" class="p-1" alt="" />
        </a>
        <p class="p-2 text-muted m-2">
            <span>الأكاديمية الجهوية: <span><?php echo e(App\Models\Information::where('status_info',1)->first()->academie ?? ''); ?></span></span><br>
            <span>المديرية الإقليمية : <span><?php echo e(App\Models\Information::where('status_info',1)->first()->direction ?? ''); ?></span></span><br>
        </p>
        <p class="p-2 text-muted m-2 h5">
            <span>المؤسسة : <span><?php echo e(App\Models\Information::where('status_info',1)->first()->etablissement ?? ''); ?></span></span><br>
        </p>
        <p class="p-2 text-muted m-2">
            <span>السنة الدراسية : <span><?php echo e(App\Models\Session::where('status_session',1)->first()->nom_session ?? ''); ?></span></span><br>
        </p>
        <form class="d-flex">
          <ul class="navbar-nav flex-row ms-auto align-items-center justify-content-end">
            <li class="nav-item">
              <a class="nav-link nav-icon-hover" href="javascript:void(0)">
                <i class="ti ti-bell-ringing"></i>
                <div class="notification bg-primary rounded-circle"></div>
              </a>

            </li>
            <li class="nav-item dropdown mx-5">
              <a class="nav-link nav-icon-hover"  href="javascript:void(0)" id="drop2" data-bs-toggle="dropdown"
                aria-expanded="false">
                <img src="<?php echo e(asset('assets/images/profile/user-1.png')); ?>" alt="" width="50" height="auto" class="rounded-circle">

              </a>
              <div class="dropdown-menu dropdown-menu-end dropdown-menu-animate-up" aria-labelledby="drop2">
                <div class="message-body">
                  <a href="javascript:void(0)" class="d-flex align-items-center gap-2 dropdown-item">
                    <i class="ti ti-user fs-6"></i>
                    <p class="mb-0 fs-3 text-uppercase"><?php echo e(Auth::user()->name); ?></p>
                  </a>
                  <a href="javascript:void(0)" class="d-flex align-items-center gap-2 dropdown-item">
                    <i class="ti ti-settings fs-6"></i>
                    <p class="mb-0 fs-3"> الإعدادات</p>
                  </a>
                  <a href="<?php echo e(route('logout')); ?>" class="btn btn-outline-primary btn-sm mx-4 mt-2 d-block">تسجيل الخروج</a>
                </div>
              </div>
            </li>
          </ul>
        </form>
      </div>
    </nav>
  </header>
<?php /**PATH C:\Users\Khadija Elmer\Desktop\absences_eleves\resources\views/includes/header.blade.php ENDPATH**/ ?>