<?php $__env->startSection('content'); ?>

<div class="inputsearch row" style="justify-content: flex-end;">



      <div class="row" >
        <div class="col-lg-12 d-flex align-items-stretch">
          <div class="card w-100">

            <div class="card-body p-4">

              <h5 class="card-title  fw-semibold mb-4">لائحة الحصص الدراسية </h5>
              <div class="col-sm-3 pl-0  ">
                <select id="id_classe" class="form-select">
                    <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $classes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($classes->id_classe); ?>"><?php echo e($classes->nom_classe_ar); ?> (<?php echo e($classes->nom_classe_fr); ?>)</option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
              </div>

              <div class="table ">
                <table class="table  mb-0 align-middle">
                  <thead class="text-dark fs-4 ">
                    <tr>
                      <th class="border-bottom-0 text-center">
                        <h6 class="fw-semibold mb-0">أيام الأسبوع</h6>
                      </th>
                      <th class="border-bottom-0">
                        <h6 class="fw-semibold mb-0"> القسم  </h6>
                      </th>

                    <th class="border-bottom-0">
                      <h6 class="fw-semibold mb-0">ح 1</h6>
                    </th>
                    <th class="border-bottom-0">
                      <h6 class="fw-semibold mb-0">ح 2</h6>
                    </th>
                    <th class="border-bottom-0">
                      <h6 class="fw-semibold mb-0">ح 3</h6>
                    </th>
                    <th class="border-bottom-0">
                      <h6 class="fw-semibold mb-0">ح 4</h6>
                    </th>
                    <th>
                        <span>|</span>
                    </th>
                    <th class="border-bottom-0">
                      <h6 class="fw-semibold mb-0">ح 5</h6>
                    </th>
                    <th class="border-bottom-0">
                      <h6 class="fw-semibold mb-0">ح 6</h6>
                    </th>
                    <th class="border-bottom-0">
                      <h6 class="fw-semibold mb-0">ح 7</h6>
                    </th>
                    <th class="border-bottom-0">
                      <h6 class="fw-semibold mb-0">ح 8</h6>
                    </th>

                    </tr>
                  </thead>
                  <tbody id="table_checkbox_seance">
                      
                      <?php

                      $weekdayNames = [
                         'الأحد',
                          'الاثنين',
                          'الثلاثاء',
                          'الأربعاء',
                          'الخميس',
                          'الجمعة',
                          'السبت',
                      ];
              ?>
                      <?php $__currentLoopData = $seances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $seances): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>

                      <td class="border-bottom-0 text-center">
                        <h6 class="fw-semibold mb-0 "><?php echo e($weekdayNames[$seances->code_jours]); ?></h6>
                      </td>
                      <td class="border-bottom-0">
                          <h6 class="fw-semibold mb-1 "><?php echo e($seances->classe->nom_classe_fr ?? ''); ?></h6>
                      </td>
                      <td>
                        <input class="checkbox_seance"  data-id_seance="<?php echo e($seances->id_seance); ?>" type="checkbox" name="s1" id="<?php echo e($seances->s1); ?>" <?php echo e($seances->s1==1 ? 'checked' : ''); ?>>
                        </td>
                        <td>
                        <input class="checkbox_seance"  data-id_seance="<?php echo e($seances->id_seance); ?>" type="checkbox" name="s2" id="<?php echo e($seances->s2); ?>" <?php echo e($seances->s2==1 ? 'checked' : ''); ?>>
                        </td>
                        <td>
                        <input class="checkbox_seance"  data-id_seance="<?php echo e($seances->id_seance); ?>" type="checkbox" name="s3" id="<?php echo e($seances->s3); ?>" <?php echo e($seances->s3==1 ? 'checked' : ''); ?>>
                        </td>
                        <td>
                        <input class="checkbox_seance"  data-id_seance="<?php echo e($seances->id_seance); ?>" type="checkbox" name="s4" id="<?php echo e($seances->s4); ?>" <?php echo e($seances->s4==1 ? 'checked' : ''); ?>>
                        </td>
                        <td></td>
                        <td>
                        <input class="checkbox_seance"  data-id_seance="<?php echo e($seances->id_seance); ?>" type="checkbox" name="s5" id="<?php echo e($seances->s5); ?>" <?php echo e($seances->s5==1 ? 'checked' : ''); ?>>
                        </td>
                        <td>
                        <input class="checkbox_seance"  data-id_seance="<?php echo e($seances->id_seance); ?>" type="checkbox" name="s6" id="<?php echo e($seances->s6); ?>" <?php echo e($seances->s6==1 ? 'checked' : ''); ?>>
                        </td>
                        <td>
                        <input class="checkbox_seance"  data-id_seance="<?php echo e($seances->id_seance); ?>" type="checkbox" name="s7" id="<?php echo e($seances->s7); ?>" <?php echo e($seances->s7==1 ? 'checked' : ''); ?>>
                        </td>
                        <td>
                        <input class="checkbox_seance"  data-id_seance="<?php echo e($seances->id_seance); ?>" type="checkbox" name="s8" id="<?php echo e($seances->s8); ?>" <?php echo e($seances->s8==1 ? 'checked' : ''); ?>>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
 <!-- modul add file-->

 <div class="modal fade" id="addseanceModal" tabindex="-1" aria-labelledby="addseanceModal"
 aria-hidden="true">
 <div class="modal-dialog">
     <div class="modal-content">
         <form action="<?php echo e(route('seance.save')); ?>" method="post" enctype="multipart/form-data">
             <?php echo csrf_field(); ?>
             <div class="modal-header">
                 <h5 class="modal-title" id=""> إضافة قسم جديد</h5>
             </div>
             <div class="modal-body">
                 <div class="col-md-12">
                     <label for="nom_seance_ar" class="form-label">إسم القسم بالعربية</label>
                     <input type="text" name="nom_seance_ar" class="form-control" id="nom_seance_ar">
                 </div>
                 <div class="col-md-12">
                    <label for="nom_seance_fr" class="form-label">إسم القسم بالفرنسية</label>
                     <input type="text" name="nom_seance_fr" class="form-control" id="nom_seance_fr">
                 </div>
             </div>
             <div class="modal-footer">
                 <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إغلاق</button>
                 <button type="submit" class="btn btn-primary">حفظ المعلومات </button>
             </div>
         </form>
     </div>
 </div>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
$("#id_classe").on("change", function(){
    $text = this.value
    $url = "<?php echo e(route('seance.filter')); ?>"
    $("#table_checkbox_seance").html("");
    get_table_ajax_find($text,$url,"#table_checkbox_seance")

    });
    $(document).on("change", ".checkbox_seance", function() {
        $seance = this.name;
        $seance_value = this.id;
        $id_seance = this.getAttribute("data-id_seance");
        $url = "<?php echo e(route('seance.update')); ?>"
        get_table_ajax_find(''+"&seance_nom="+$seance+"&"+$seance+"="+$seance_value+"&id_seance="+$id_seance,$url,"#table_checkbox_seance")

        });
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Khadija Elmer\Desktop\absences_eleves\resources\views/pages/seances/index.blade.php ENDPATH**/ ?>