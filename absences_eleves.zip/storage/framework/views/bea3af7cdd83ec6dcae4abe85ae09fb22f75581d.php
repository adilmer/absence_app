<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-body">
        <h2 class="card-title fw-semibold mb-4">تفاصيل الطالب</h2>
        <hr>
        <div class="row text-bold text-muted">
            <div class="col-md-4">
                <h4 class="m-2">معلومات التلميذ<hr></h4>
                <ul class="list-group">
                    <li class="list-group-item"> الرقم الترتيبي داخل الفصل :  <?php echo e($eleve->num_eleve); ?></li>
                    <li class="list-group-item">رقم مسار :  <?php echo e($eleve->mat); ?></li>
                    <li class="list-group-item">الإسم الكامل بالعربية :  <?php echo e($eleve->nom_ar); ?> <?php echo e($eleve->prenom_ar); ?></li>
                    <li class="list-group-item">الإسم الكامل بالفرنسية :  <?php echo e($eleve->nom_fr); ?> <?php echo e($eleve->prenom_fr); ?></li>
                    <li class="list-group-item">الجنس :  <?php echo e($eleve->sexe); ?></li>
                    <li class="list-group-item">تاريخ الإزدياد :  <?php echo e($eleve->date_naiss->format('Y-m-d')); ?></li>
                    <li class="list-group-item">مكان الإزدياد بالعربية :  <?php echo e($eleve->lieu_naiss_ar); ?></li>
                    <li class="list-group-item">المستوى والقسم :  <?php echo e($eleve->classe->nom_classe_ar); ?> ( <?php echo e($eleve->classe->nom_classe_fr); ?> )</li>
                </ul>
            </div>
            <div class="col-md-7">
                <h4 class="m-2">بيانات ولي الأمر <a href="<?php echo e(route('eleve.edit',$eleve->id_eleve)); ?>" class="btn btn-sm btn-warning mx-2" style="float: left"><i class="ti ti-edit"></i> تعديل </a><hr></h4>
                <table class="table">
                    <thead>
                        <th>الإسم الكامل</th>
                        <th>نوع الوصاية</th>
                        <th>المهنة</th>
                        <th>رقم البطاقة الوطنية</th>
                        <th>رقم الهاتف</th>
                        <th> العنوان</th>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $parents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parents): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($parents->nom_parent_ar); ?> <?php echo e($parents->prenom_parent_ar); ?></td>
                                <td><?php echo e($parents->type_parent); ?></td>
                                <td><?php echo e($parents->profession); ?></td>
                                <td><?php echo e($parents->cin); ?></td>
                                <?php
                                    $etab = App\Models\Information::where('status_info',1)->first()->etablissement ;
                                    $nom_eleve =  $parents->eleve->nom_ar ." ". $parents->eleve->prenom_ar ;
                                    $text = "السلام عليكم نعلمكم نحن مكتب الحراسة العامة بمؤسسة $etab بالحضور قصد تسوية وضعية التلميذ $nom_eleve في أقرب وقت وشكرا"
                                ?>
                                <td><a target="_blank" href="https://api.whatsapp.com/send/?phone=212<?php echo e(substr($parents->tel,1)); ?>&text=<?php echo e($text); ?>"><?php echo e($parents->tel); ?></a></td>
                                <td><?php echo e($parents->adresse); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

            <div class="col-md-12 m-4">
                <p class="m-2"></span><span class="h4">بيانات الغياب<a href="<?php echo e(route('absence.edit',$eleve->id_eleve)); ?>" class="btn btn-sm btn-secondary mx-2" style="float: left"><i class="ti ti-edit"></i> تعديل </a><hr></span><span class="text-small text-center">
                    <table class="table table-info table-bordered">
                    <tr class="">
                     <th class="mx-2"> مجموع ساعات الغياب المبررة  : </th>
                     <th class="mx-2"><?php echo e($absences->where('status_absence','<>',1)->sum('total_seances')); ?>  </th>
                     <th class="mx-2"> مجموع أيام الغياب المبررة  : </th>
                     <th class="mx-2"><?php echo e($absences->where('status_absence','<>',1)->sum('total_jours')); ?>  </th>
                     <th class="mx-1"> مجموع ساعات الغياب الغير المبررة  : </th>
                     <th class="mx-1"><?php echo e($absences->where('status_absence','=',1)->sum('total_seances')); ?>  </th>
                     <th class="mx-1"> مجموع أيام الغياب الغير المبررة  : </th>
                     <th class="mx-1"><?php echo e($absences->where('status_absence','=',1)->sum('total_jours')); ?>  </th>
                </tr>
            </table>
                </span></p>
                <table class="table text-center">
                    <thead>
                        <th> التاريخ</th>
                        <th>ساعات الغياب </th>
                        <th>أيام الغياب </th>
                        <th>التبرير</th>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $absences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $absences): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($absences->date->format('Y-m-d')); ?></td>
                            <td><?php echo e($absences->total_seances); ?></td>
                            <td><?php echo e($absences->total_jours); ?></td>
                            <td><?php echo e($absences->motif_absence->nom_motif); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Khadija Elmer\Desktop\absences_eleves\resources\views/pages/eleves/details.blade.php ENDPATH**/ ?>