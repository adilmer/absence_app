<script>
    var ctx = document.getElementById("<?php echo e($options['chart_name'] ?? 'myChart'); ?>");
    var mycolors= [];
    var mycolor= [];
    <?php
    $mycolor= 	['rgba(255,0,0,0.1)','rgba(0,255,0,0.1)','rgba(0,255,255,0.1)'];
    $mycolors= 	["#00BFFF","#00FFBF","#BF00FF","#FF69B4","#FFB469","#6933B4","#FFEFD5","#FFD5EF","#EFFFD5"];
    ?>
    var <?php echo e($options['chart_name'] ?? 'myChart'); ?> = new Chart(ctx, {
        type: '<?php echo e($options['chart_type'] ?? 'line'); ?>',
        data: {
            labels: [
                <?php if(count($datasets) > 0): ?>
                    <?php $__currentLoopData = $datasets[0]['data']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group => $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        "<?php echo e($group); ?>",
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            ],
        datasets: [
            <?php $__currentLoopData = $datasets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dataset): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            {
                label: '<?php echo e($dataset['name'] ?? $options['chart_title']); ?>',
                data: [
                    <?php $__currentLoopData = $dataset['data']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group => $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo $result; ?>,
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                ],
                <?php if($dataset['hidden'] === true): ?>
                    hidden: true,
                <?php endif; ?>
                <?php if($options['chart_type'] == 'line'): ?>
                    <?php if(isset($dataset['fill']) && $dataset['fill'] != ''): ?>
                        fill: '<?php echo e($dataset['fill']); ?>',
                    <?php else: ?>
                        fill: true,
                        backgroundColor: '<?php echo e($mycolor[$loop->iteration-1]); ?>',
                    <?php endif; ?>
                    <?php if(isset($dataset['color']) && $dataset['color'] != ''): ?>
                        borderColor: '<?php echo e($dataset['color']); ?>',
                    <?php elseif(isset($dataset['chart_color']) && $dataset['chart_color'] != ''): ?>
                        borderColor: 'rgba(<?php echo e($dataset['chart_color']); ?>)',
                    <?php else: ?>
                        borderColor: '<?php echo e($mycolor[$loop->iteration-1]); ?>',
                    <?php endif; ?>

                <?php elseif($options['chart_type'] == 'pie'): ?>
                    backgroundColor: [
                        <?php $__currentLoopData = $dataset['data']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group => $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if( $dataset['chart_color'] != ''): ?>
                                '<?php echo e($dataset['chart_color'][$loop->iteration-1]); ?>',
                            <?php else: ?>
                                '<?php echo e($mycolors[$loop->iteration-1]); ?>',
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    ],
                <?php elseif($options['chart_type'] == 'bar' && isset($dataset['chart_color']) && $dataset['chart_color'] != ''): ?>
                    borderColor: '<?php echo e($dataset['chart_color']); ?>',
                    backgroundColor: '<?php echo e($dataset['chart_color']); ?>',
                <?php endif; ?>
                borderWidth: 1
            },
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        ]
    },
    options: {
        tooltips: {
            mode: 'point'
        },
        height: '<?php echo e($options['chart_height'] ?? "300px"); ?>',
        <?php if($options['chart_type'] != 'pie'): ?>
            scales: {
                xAxes: [],
                yAxes: [{
                    ticks: {
                        beginAtZero:true
                    },
                    <?php if($options['chart_type'] == 'bar' && isset($options['stacked']) && $options['stacked'] == true): ?>
                        stacked: true
                    <?php endif; ?>
                }]
            },
        <?php endif; ?>
    }
    });
</script>
<?php /**PATH C:\Users\Khadija Elmer\Desktop\absences_eleves\vendor\laraveldaily\laravel-charts\src/views/javascript.blade.php ENDPATH**/ ?>